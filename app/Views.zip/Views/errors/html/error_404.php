<section id="main">
    <div class="container">
        <div class="row">
            <div class="error-404">
                <h1>404</h1>
                <h2><?= "Sayfa Bulunamadı"; ?></h2>
                <p><?= "Sayfa bulunamadı alt başlığı"; ?></p>
                <a class="btn btn-lg btn-custom" href="<?= langBaseUrl(); ?>"><?= "Ana Sayfaya Git"; ?></a>
            </div>
        </div>
    </div>
</section>